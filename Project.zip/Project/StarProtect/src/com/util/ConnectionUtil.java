package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionUtil {
     public static Connection createConnection() throws ClassNotFoundException, SQLException
     {
    	 Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
    	 Connection cn=DriverManager.getConnection("jdbc:derby:C:\\Users\\Sravani\\MyDB;create=true","user","derby");
    	 return cn;
    	 
     }
     public static void closeConnection(Connection cn) throws SQLException 
     {
    	 cn.close();
     }
}
