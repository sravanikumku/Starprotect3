package com.view;

import java.util.Scanner;

public class UnderWriterView {
	public void showConsole(String value)
	  {
		  while(true)
		  {
		    System.out.println(value+" Login");
		    System.out.println("-----------");
		    System.out.print("Enter UserId:_");
		    Scanner sc=new Scanner(System.in);
		    String userId=sc.nextLine();
		    System.out.print("Enter Password:_");
		    String passwd=sc.nextLine();
		    if(userId.equals("userid") && passwd.equals("1234")/*|| UnderWriterService.checkCred()*/)
		    {
		    	System.out.print("Login Successful!");
		    	System.out.println(" Redirecting to  Dashboard...");
		    }
		    else
		    {
		    	return;
		    }
		   
		   }
	  }
}
