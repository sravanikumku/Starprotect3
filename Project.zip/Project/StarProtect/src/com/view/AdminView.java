package com.view;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

import com.model.UnderWriter;
import com.service.AdminService;

public class AdminView {
	
  public void showConsole(String value) throws ClassNotFoundException, SQLException, ParseException
  {
	 while(true)
	 {
	    System.out.println(value+" Login");
	    System.out.println("-----------");
	    System.out.print("Enter UserId:_");
	    Scanner sc=new Scanner(System.in);
	    String userId=sc.nextLine();
	    System.out.print("Enter Password:_");
	    String passwd=sc.nextLine();
	    if(userId.equals("admin") && passwd.equals("1234"))
	    {
	    	 System.out.print("Login Successful!");
		     System.out.println(" Redirecting to Admin Dashboard...");
		     printAdminDashboard();
		     int ch=sc.nextInt();
		     AdminService ad=new AdminService();
		     switch(ch)
		        {          
		            case 1:
		            	
		            	   ad.registerVehicle();
		                   
		                    break;
//		           case 2:ad.searchById();
//		                    break;
//		           case 3:ad.updatePwd();
//		                    break;
//		           case 4:ad.deleteById();
//		                    break;
//		           case 5:ad.view();
//		                    break;
//		           case 6:ad.viewById();
//		                    break;
		           default:
		                   System.out.println("Logout successfully!");
		                  
		                   
		           
		        }
	    }
	    else
	    {
	    	System.out.println("Invalid Credentials!\n1.Please try again \n2.Press x to exit ");
	    	char ch=sc.nextLine().charAt(0);
	    	if(ch=='x')
	    	{
	    		return;
	    	}
	    	
	    	
	    }
	}
	   
  }

  void printAdminDashboard()
	{
	    System.out.println("Admin Dashboard");
	    System.out.println("----------------");
	    System.out.println("1. Register UnderWriter");
	    System.out.println("2. Search UnderWriter by Id");
	    System.out.println("3. Update UnderWriter Password");
	    System.out.println("4. Delete UnderWriter by Id");
	    System.out.println("5. View All UnderWriters");
	    System.out.println("6. View Vehicles by UnderWriter Id");
	    System.out.println("7. Logout");
	    System.out.print("Enter your choice:_");
	    
	}
}
