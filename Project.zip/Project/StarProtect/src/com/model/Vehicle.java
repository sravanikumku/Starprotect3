package com.model;

public class Vehicle {

}
