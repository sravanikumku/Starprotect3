package com.model;

public class UnderWriter {
	public int uid;
	public String name;
	public String dob;
	public String doj;
	public String pwd;
	public UnderWriter(int uid, String name, String dob, String doj, String pwd) {
		super();
		this.uid = uid;
		this.name = name;
		this.dob = dob;
		this.doj = doj;
		this.pwd = pwd;
	}
	UnderWriter()
	{
		
	}
}
