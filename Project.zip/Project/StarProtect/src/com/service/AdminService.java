package com.service;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.Random;
import java.util.Scanner;

import com.dao.AdminDao;
import com.model.UnderWriter;




public class AdminService {
	 int generateUwid(int len)
	    {
	        String chars="0123456789";
	        Random random=new Random();
	        StringBuilder uid=new StringBuilder();
	        for(int i=0;i<len;i++)
	        {
	            uid.append(chars.charAt(random.nextInt(chars.length())));
	        }
	        return Integer.parseInt(uid.toString());
	        
	    }

	 public void registerVehicle() throws ClassNotFoundException, SQLException, ParseException
	  {
		  Scanner sc=new Scanner(System.in);
	      System.out.println("Register UnderWriter");
	      System.out.println("-------------------");
	      int uid=generateUwid(8);
	      System.out.println("UnderWriter ID:_"+uid);
	      System.out.print("Enter Name:_");
	      String name=sc.nextLine();
	      System.out.print("Enter Date of Birth (DD/MM/YYYY):_");
	      String dob=sc.nextLine();
	      System.out.print("Enter Joining Date (DD/MM/YYYY):_");
	      String doj=sc.nextLine();
	      System.out.print("Enter Password (Alphanumeric):_");
	      String pwd=sc.nextLine();
	      String regex="(?=.*[A-Za-z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).*";
	      while(true)
	      {
	      if(pwd.matches(regex))
	      {
	          System.out.println("Password updated successfully!");
	          UnderWriter uwd=new UnderWriter(uid,name,dob,doj,pwd);
	          AdminDao ad=new AdminDao();
	          ad.register(uwd);
	          break;
	      }
	      else
	      {
	          System.out.println("Password must be alphanumeric . Please enter again.");
	          System.out.print("Enter Password (Alphanumeric):_");
	          pwd=sc.nextLine();
	      }
	      }
	       
	      
	  }
}
