package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.model.UnderWriter;
import com.util.ConnectionUtil;

public class AdminDao {
		public void register(UnderWriter uwd) throws ClassNotFoundException, SQLException, ParseException
		{
			Connection cn=ConnectionUtil.createConnection();
			 java.util.Date dob1,doj1;
			  SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
			
	         dob1=formatter.parse(uwd.dob);
	         doj1=formatter.parse(uwd.doj);
	         java.sql.Date dob = new java.sql.Date(dob1.getTime());
	         
	         java.sql.Date doj = new java.sql.Date(doj1.getTime());
			String sql="insert into UnderWriter values(?,?,?,?,?)";
			PreparedStatement ps=cn.prepareStatement(sql);
			ps.setInt(1, uwd.uid);
			ps.setString(2, uwd.name);
			ps.setDate(3, dob);
			ps.setDate(4, doj);
			ps.setString(5, uwd.pwd);
			
			ConnectionUtil.closeConnection(cn);
			
			
		}
}
