import java.sql.SQLException;
import java.text.ParseException;
import java.util.Scanner;

import com.view.AdminView;
import com.view.UnderWriterView;
public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, ParseException {
		// TODO Auto-generated method stub
		System.out.println("Welcome to Star Protect Vehicle System");
		while(true)
		{
			
			System.out.println("--------------------------------------");
			System.out.println("Select your Role:");
		    System.out.println("1. Admin");
		    System.out.println("2. UnderWriter");
		    System.out.println("3. Exit");
		    System.out.print("Enter your choice:_");
		    Scanner sc=new Scanner(System.in);
		    int role=sc.nextInt();
		    switch(role)
		    {
		        case 1:
		               AdminView ad=new AdminView();
		               ad.showConsole("Admin");
		               break;
		       case 2:
		              UnderWriterView uwd=new UnderWriterView();
		              uwd.showConsole("UnderWriter");
		              break;
		       case 3:System.exit(0);
		               
		       default:
		                System.out.println("Invalid Choice! Try again");
		       
		    }
		}

	}
	

}
